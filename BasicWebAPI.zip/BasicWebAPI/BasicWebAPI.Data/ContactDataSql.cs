﻿using BasicWebAPI.Core;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicWebAPI.Data
{
    public class ContactDataSql : IContactData
    {
        private readonly BasicWebAPIDbContext basicWebAPIDbContext;
        public ContactDataSql(BasicWebAPIDbContext basicWebAPIDbContext)
        {
            this.basicWebAPIDbContext = basicWebAPIDbContext;
        }

        public Contact Create(Contact contact)
        {
            basicWebAPIDbContext.Contacts.Add(contact);
            return contact;
        }
        public int Commit()
        {
            return basicWebAPIDbContext.SaveChanges();
        }
        public Contact Delete(int contactId)
        {
            var tempContact = basicWebAPIDbContext.Contacts.SingleOrDefault(c => c.ContactId == contactId);
            if (tempContact != null)
            {
                basicWebAPIDbContext.Contacts.Remove(tempContact);
            }
            return tempContact;
        }

        public Contact GetContactById(int contactId)
        {
            return basicWebAPIDbContext.Contacts.SingleOrDefault(c => c.ContactId == contactId);
        }

        public IEnumerable<Contact> GetContacts(string name = null)
        {
            var param = !string.IsNullOrEmpty(name) ? $"{name}%" : name;
            return basicWebAPIDbContext.Contacts.Where(c => string.IsNullOrEmpty(name) || EF.Functions.Like(c.ContactName, param)).ToList();
        }

        public Contact Update(Contact contact)
        {
            basicWebAPIDbContext.Entry(contact).State = EntityState.Modified;
            return contact;
        }
    }
}
