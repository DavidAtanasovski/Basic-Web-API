﻿using BasicWebAPI.Core;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicWebAPI.Data
{
    public class CompanyDataSql : ICompanyData
    {
        private readonly BasicWebAPIDbContext basicWebAPIDbContext;
        public  CompanyDataSql (BasicWebAPIDbContext basicWebAPIDbContext)
        {
            this.basicWebAPIDbContext = basicWebAPIDbContext;
        }
        public int Commit()
        {
            return basicWebAPIDbContext.SaveChanges();
        }

        public Company Create(Company company)
        {
            basicWebAPIDbContext.Companies.Add(company);
            return company;
        }

        public Company Delete(int companyId)
        {
            var tempCompany = basicWebAPIDbContext.Companies.SingleOrDefault(c => c.CompanyId == companyId);
            if (tempCompany != null)
            {
                basicWebAPIDbContext.Companies.Remove(tempCompany);
            }
            return tempCompany;
        }

        public IEnumerable<Company> GetCompanies(string name = null)
        {
            var param = !string.IsNullOrEmpty(name) ? $"{name}%" : name;
            return basicWebAPIDbContext.Companies.Where(c => string.IsNullOrEmpty(name) || EF.Functions.Like(c.CompanyName, param)).ToList();
        }

        public Company GetCompanyById(int companyId)
        {
            return basicWebAPIDbContext.Companies.SingleOrDefault(c => c.CompanyId == companyId);
        }

        public Company Update(Company company)
        {
            basicWebAPIDbContext.Entry(company).State = EntityState.Modified;
            return company;
        }
    }
}
