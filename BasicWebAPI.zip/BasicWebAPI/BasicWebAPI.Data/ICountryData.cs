﻿using BasicWebAPI.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicWebAPI.Data
{
    public interface ICountryData
    {

        IEnumerable<Country> GetCountries(string name = null);
        Country Create(Country country);
        Country Update(Country country);
        Country Delete(int countryId);
        Country GetCountryById(int countryId);
        int Commit();
    }
}
