﻿using BasicWebAPI.Core;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicWebAPI.Data
{
    public class CountryDataSql : ICountryData
    {
        private readonly BasicWebAPIDbContext basicWebAPIDbContext;
        public CountryDataSql(BasicWebAPIDbContext basicWebAPIDbContext)
        {
            this.basicWebAPIDbContext = basicWebAPIDbContext;
        }

        public int Commit()
        {
            return basicWebAPIDbContext.SaveChanges();
        }

        public Country Create(Country country)
        {
            basicWebAPIDbContext.Countries.Add(country);
            return country;
        }

        public Country Delete(int countryId)
        {
            var tempCountry = basicWebAPIDbContext.Countries.SingleOrDefault(c => c.CountryId == countryId);
            if (tempCountry != null)
            {
                basicWebAPIDbContext.Countries.Remove(tempCountry);
            }
            return tempCountry;
        }

        public IEnumerable<Country> GetCountries(string name = null)
        {
            var param = !string.IsNullOrEmpty(name) ? $"{name}%" : name;
            return basicWebAPIDbContext.Countries.Where(c => string.IsNullOrEmpty(name) || EF.Functions.Like(c.CountryName, param)).ToList();
        }

        public Country GetCountryById(int countryId)
        {
            return basicWebAPIDbContext.Countries.SingleOrDefault(c => c.CountryId == countryId);
        }

        public Country Update(Country country)
        {
            basicWebAPIDbContext.Entry(country).State = EntityState.Modified;
            return country;
        }
    }
}
