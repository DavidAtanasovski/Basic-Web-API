﻿using BasicWebAPI.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicWebAPI.Data
{
    public interface IContactData
    {
        IEnumerable<Contact> GetContacts(string name = null);
        Contact Create(Contact contact);
        Contact Update(Contact contact);
        Contact Delete(int contactId);
        Contact GetContactById(int contactId);
        int Commit();
    }
}
