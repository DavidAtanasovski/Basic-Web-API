﻿using BasicWebAPI.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicWebAPI.Data
{
    public interface ICompanyData
    {
        IEnumerable<Company> GetCompanies(string name = null);
        Company Create(Company company);
        Company Update(Company company);
        Company Delete(int companyId);
        Company GetCompanyById(int companyId);

        int Commit();

    }
}
