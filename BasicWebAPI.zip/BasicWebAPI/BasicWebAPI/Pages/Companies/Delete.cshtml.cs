using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BasicWebAPI.Core;
using BasicWebAPI.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BasicWebAPI.Pages.Companies
{
    public class DeleteModel : PageModel
    {
        private readonly ICompanyData companyData;

        public Company Company { get; set; }

        public DeleteModel(ICompanyData companyData)
        {
            this.companyData = companyData;
        }

        public IActionResult OnGet(int companyId)
        {
            Company = companyData.GetCompanyById(companyId);
            if(Company == null)
            {
                return RedirectToPage("./NotFound");
            }
            return Page();
        }

        public IActionResult OnPost(int companyId)
        {
            var temp = companyData.Delete(companyId);
            if(temp == null)
            {
                return RedirectToPage("./NotFound");
            }

            companyData.Commit();
            TempData["TempMessage"] = "Deleted";
            return RedirectToPage("./List");
        }
    }
}
