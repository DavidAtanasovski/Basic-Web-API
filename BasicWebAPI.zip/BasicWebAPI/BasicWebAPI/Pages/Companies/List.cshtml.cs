using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BasicWebAPI.Core;
using BasicWebAPI.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace BasicWebAPI.Pages.Companies
{
    public class ListModel : PageModel
    {
       
        private readonly ICompanyData companyData;
       

      

        [BindProperty(SupportsGet =true)]
        public string SearchTerm { get; set; }

        public IEnumerable<Company> Companies { get; set; }

        public ListModel( ICompanyData companyData)
        {
        
            this.companyData = companyData;
         
        }

        public void OnGet()
        {
          
            Companies = companyData.GetCompanies(SearchTerm);
        }
    }
}
