using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BasicWebAPI.Core;
using BasicWebAPI.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace BasicWebAPI.Pages.Companies
{
    public class EditModel : PageModel
    {
        private readonly ICompanyData companyData;
      

        [BindProperty]
        public Company Company { get; set; }

      

        public EditModel(ICompanyData companyData)
        {
            this.companyData = companyData;
      
        }

        public IActionResult OnGet(int? companyId)
        {
            if (companyId.HasValue)
            {
                Company = companyData.GetCompanyById(companyId.Value);
                if (Company == null)
                {
                    return RedirectToPage("./NotFound");
                }
            }
            else
            {
                Company = new Company();
            }


            return Page();
        }

        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                if (Company.CompanyId == 0)
                {
                    Company = companyData.Create(Company);
                    TempData["Message"] = "The Object is created!";
                }
                else
                {
                    Company = companyData.Update(Company);
                    TempData["Message"] = "The Object is updated!";
                }

                companyData.Commit();
                return RedirectToPage("./Detail", new { companyId = Company.CompanyId });
            }

            return Page();
        }
    }
}
