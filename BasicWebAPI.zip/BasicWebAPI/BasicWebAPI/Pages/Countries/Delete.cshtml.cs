using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BasicWebAPI.Core;
using BasicWebAPI.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BasicWebAPI.Pages.Countries
{
    public class DeleteModel : PageModel
    {
        private readonly ICountryData countryData ;

        public Country Country { get; set; }

        public DeleteModel(ICountryData countryData)
        {
            this.countryData = countryData;
        }

        public IActionResult OnGet(int countryId)
        {
            Country = countryData.GetCountryById(countryId);
            if (Country == null)
            {
                return RedirectToPage("./NotFound");
            }
            return Page();
        }

        public IActionResult OnPost(int countryId)
        {
            var temp = countryData.Delete(countryId);
            if (temp == null)
            {
                return RedirectToPage("./NotFound");
            }

            countryData.Commit();
            TempData["TempMessage"] = "Deleted";
            return RedirectToPage("./List");
        }
    }
}
