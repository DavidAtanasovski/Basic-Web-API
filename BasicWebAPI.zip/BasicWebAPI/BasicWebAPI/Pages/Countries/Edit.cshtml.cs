using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BasicWebAPI.Core;
using BasicWebAPI.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BasicWebAPI.Pages.Countries
{
    public class EditModel : PageModel
    {
        private readonly ICountryData countryData;


        [BindProperty]
        public Country Country { get; set; }



        public EditModel(ICountryData countryData)
        {
            this.countryData = countryData;

        }

        public IActionResult OnGet(int? countryId)
        {
            if (countryId.HasValue)
            {
                Country = countryData.GetCountryById(countryId.Value);
                if (Country == null)
                {
                    return RedirectToPage("./NotFound");
                }
            }
            else
            {
                Country = new Country();
            }


            return Page();
        }

        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                if (Country.CountryId == 0)
                {
                    Country = countryData.Create(Country);
                    TempData["Message"] = "The Object is created!";
                }
                else
                {
                    Country = countryData.Update(Country);
                    TempData["Message"] = "The Object is updated!";
                }

                countryData.Commit();
                return RedirectToPage("./Detail", new { countryId = Country.CountryId });
            }

            return Page();
        }
    }
}
