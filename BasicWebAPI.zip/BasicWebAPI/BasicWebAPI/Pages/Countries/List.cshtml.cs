using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BasicWebAPI.Core;
using BasicWebAPI.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BasicWebAPI.Pages.Countries
{
    public class ListModel : PageModel
    {
        private readonly ICountryData countryData;




        [BindProperty(SupportsGet = true)]
        public string SearchTerm { get; set; }

        public IEnumerable<Country> Countries { get; set; }

        public ListModel(ICountryData countryData)
        {

            this.countryData = countryData;

        }

        public void OnGet()
        {

            Countries = countryData.GetCountries(SearchTerm);
        }
    }
}
