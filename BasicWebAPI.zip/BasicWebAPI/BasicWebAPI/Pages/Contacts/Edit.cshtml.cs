using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BasicWebAPI.Core;
using BasicWebAPI.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BasicWebAPI.Pages.Contacts
{
    public class EditModel : PageModel
    {
        private readonly IContactData contactData;


        [BindProperty]
        public Contact Contact { get; set; }



        public EditModel(IContactData contactData)
        {
            this.contactData = contactData;

        }

        public IActionResult OnGet(int? contactId)
        {
            if (contactId.HasValue)
            {
                Contact = contactData.GetContactById(contactId.Value);
                if (Contact == null)
                {
                    return RedirectToPage("./NotFound");
                }
            }
            else
            {
                Contact = new Contact();
            }


            return Page();
        }

        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                if (Contact.ContactId == 0)
                {
                    Contact = contactData.Create(Contact);
                    TempData["Message"] = "The Object is created!";
                }
                else
                {
                    Contact = contactData.Update(Contact);
                    TempData["Message"] = "The Object is updated!";
                }

                contactData.Commit();
                return RedirectToPage("./Detail", new { contactId = Contact.ContactId });
            }

            return Page();
        }
    }
}
