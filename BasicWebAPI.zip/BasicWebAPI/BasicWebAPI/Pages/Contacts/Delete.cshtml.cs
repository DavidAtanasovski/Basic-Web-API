using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BasicWebAPI.Core;
using BasicWebAPI.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BasicWebAPI.Pages.Contacts
{
    public class DeleteModel : PageModel
    {
        private readonly IContactData contactData;

        public Contact Contact { get; set; }

        public DeleteModel(IContactData contactData)
        {
            this.contactData = contactData;
        }

        public IActionResult OnGet(int contactId)
        {
            Contact = contactData.GetContactById(contactId);
            if (Contact == null)
            {
                return RedirectToPage("./NotFound");
            }
            return Page();
        }

        public IActionResult OnPost(int contactId)
        {
            var temp = contactData.Delete(contactId);
            if (temp == null)
            {
                return RedirectToPage("./NotFound");
            }

            contactData.Commit();
            TempData["TempMessage"] = "Deleted";
            return RedirectToPage("./List");
        }
    }
}
