using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BasicWebAPI.Core;
using BasicWebAPI.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BasicWebAPI.Pages.Contacts
{
    public class ListModel : PageModel
    {
        private readonly IContactData contactData;




        [BindProperty(SupportsGet = true)]
        public string SearchTerm { get; set; }

        public IEnumerable<Contact> Contacts { get; set; }

        public ListModel(IContactData contactData)
        {

            this.contactData = contactData;

        }

        public void OnGet()
        {

            Contacts = contactData.GetContacts(SearchTerm);
        }
    }
}
