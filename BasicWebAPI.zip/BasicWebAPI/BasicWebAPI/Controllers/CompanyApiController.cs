﻿using BasicWebAPI.Core;
using BasicWebAPI.Data;
using BasicWebAPI.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BasicWebAPI.Controllers
{
    [Route("api/Companies")]
    [ApiController]
    public class CompanyApiController : Controller
    {
        private readonly ICompanyData companyData;
        public CompanyApiController (ICompanyData companyData)
        {
            this.companyData = companyData;
        }

        [HttpGet]
        public IActionResult GetAllCompanies()
        {
            var data = companyData.GetCompanies();
            return Ok(data);
        }

        [HttpGet("{companyId")]
        public IActionResult GetCompany(int companyId)
        {
            var data = companyData.GetCompanyById(companyId);
            if (data == null)
            {
                return NotFound();
            }
            return Ok(data);
        }

        [HttpPost]
        public IActionResult Create(CompanyDto companyCreateDto)
        {
            if (companyCreateDto == null)
            {
                return BadRequest();
            }
            var company = new Company();
            company.CompanyName = companyCreateDto.CompanyName;

            companyData.Create(company);
            companyData.Commit();
            return CreatedAtRoute("GetCompany", new { id = company.CompanyId }, company);

        }

        [HttpDelete("{companyId}")]
        public IActionResult Delete(int companyId)
        {
            var temp = companyData.Delete(companyId);
            if (temp == null)
            {
                return BadRequest();
            }
            companyData.Commit();
            return NoContent();
        }
    }
}
