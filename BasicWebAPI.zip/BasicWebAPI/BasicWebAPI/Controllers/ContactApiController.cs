﻿using BasicWebAPI.Core;
using BasicWebAPI.Data;
using BasicWebAPI.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BasicWebAPI.Controllers
{
    public class ContactApiController : Controller
    {
        [Route("api/Contacts")]
        [ApiController]
        public class CompanyApiController : Controller
        {
            private readonly IContactData contactData;
            public CompanyApiController(IContactData contactData)
            {
                this.contactData = contactData;
            }

            [HttpGet]
            public IActionResult GetAllContacts()
            {
                var data = contactData.GetContacts();
                return Ok(data);
            }

            [HttpGet("{conactId")]
            public IActionResult GetContact(int contactId)
            {
                var data = contactData.GetContactById(contactId);
                if (data == null)
                {
                    return NotFound();
                }
                return Ok(data);
            }

            [HttpPost]
            public IActionResult Create(ContactDto contactCreateDto)
            {
                if (contactCreateDto == null)
                {
                    return BadRequest();
                }
                var contact = new Contact();
                contact.ContactName = contactCreateDto.ContactName;

                contactData.Create(contact);
                contactData.Commit();
                return CreatedAtRoute("GetContact", new { id = contact.ContactId }, contact);

            }

            [HttpDelete("{contactId}")]
            public IActionResult Delete(int contactId)
            {
                var temp = contactData.Delete(contactId);
                if (temp == null)
                {
                    return BadRequest();
                }
                contactData.Commit();
                return NoContent();
            }
        }
    }
}
