﻿using BasicWebAPI.Core;
using BasicWebAPI.Data;
using BasicWebAPI.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BasicWebAPI.Controllers
{
    public class CountryApiController : Controller
    {
        [Route("api/Countries")]
        [ApiController]
        public class CompanyApiController : Controller
        {
            private readonly ICountryData countryData;
            public CompanyApiController(ICountryData countryData)
            {
                this.countryData = countryData;
            }

            [HttpGet]
            public IActionResult GetAllCountries()
            {
                var data = countryData.GetCountries();
                return Ok(data);
            }

            [HttpGet("{counrtyId")]
            public IActionResult GetCountry(int countryId)
            {
                var data = countryData.GetCountryById(countryId);
                if (data == null)
                {
                    return NotFound();
                }
                return Ok(data);
            }

            [HttpPost]
            public IActionResult Create(CountryDtocs countryCreateDto)
            {
                if (countryCreateDto == null)
                {
                    return BadRequest();
                }
                var country = new Country();
                country.CountryName = countryCreateDto.CountryName;

                countryData.Create(country);
                countryData.Commit();
                return CreatedAtRoute("GetCountry", new { id = country.CountryId }, country);

            }

            [HttpDelete("{countryId}")]
            public IActionResult Delete(int countryId)
            {
                var temp = countryData.Delete(countryId);
                if (temp == null)
                {
                    return BadRequest();
                }
                countryData.Commit();
                return NoContent();
            }
        }
    }
}
